//
//  vegInfoViewController.swift
//  FoodCorner
//
//  Created by Anilkumar on 08/07/22.
//

import UIKit

class vegInfoViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    var selectedProdName = ""
   
    @IBOutlet weak var vegHeadImage: UIImageView!
    @IBOutlet weak var vegInfoTableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if(UIScreen.main.bounds.height < 600)
        {
            vegHeadImage.heightAnchor.constraint(equalToConstant: 120).isActive = true
            vegHeadImage.translatesAutoresizingMaskIntoConstraints = false
        }
        
        vegInfoTableView.delegate = self
        vegInfoTableView.dataSource = self
        
        vegInfoTableView.register(vegInfoCustomTableViewCell.self, forCellReuseIdentifier: "Cell")

        // Do any additional setup after loading the view.
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return vegArr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)as?
                vegInfoCustomTableViewCell else {fatalError("Unable to run")}
        
        
        cell.fastFoodImage.image = UIImage(named: "\(vegArr[indexPath.row])")
        cell.fastFoodName.text = vegArr[indexPath.row].uppercased()
        cell.fastFoodAddress.text = "\(vegAddressArr[indexPath.row])"
        cell.fastFoodRate.text = "\(vegRatingArr[indexPath.row])"
        cell.fastFoodImage.backgroundColor = .gray
          
        
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let vc = storyboard?.instantiateViewController(withIdentifier: "ProductInfoViewController") as! ProductInfoViewController
            self.selectedProdName = "\(vegArr[indexPath.item])"
            vc.productArr = "vegArr"
        
        vc.ProdName = self.selectedProdName
        vc.productAddress = vegAddressArr[indexPath.item]
    
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 120
    }
    


}
