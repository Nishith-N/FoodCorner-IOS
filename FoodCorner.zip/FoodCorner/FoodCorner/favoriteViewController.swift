//
//  favoriteViewController.swift
//  FoodCorner
//
//  Created by Anilkumar on 02/07/22.
//

import UIKit

class favoriteViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    
    @IBOutlet weak var emptyLabel: UILabel!
    var selectedProdName = ""
    @IBOutlet weak var favoriteInfoTableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        favoriteInfoTableView.delegate = self
        favoriteInfoTableView.dataSource = self
        
        emptyLabel.topAnchor.constraint(equalTo: view.topAnchor, constant: (UIScreen.main.bounds.height/2)-50).isActive = true
        emptyLabel.heightAnchor.constraint(equalToConstant: 100).isActive = true
        emptyLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20).isActive = true
        emptyLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20).isActive = true
        emptyLabel.translatesAutoresizingMaskIntoConstraints = false
        
        
        if(myFavName.count == 0)
        {
            emptyLabel.isHidden = false
            favoriteInfoTableView.isHidden = true
           
        }
        else
        {
            emptyLabel.isHidden = true
            favoriteInfoTableView.isHidden = false
            
        }
        if let tabItems = tabBarController?.tabBar.items {
            // In this case we want to modify the badge number of the third tab:
            let tabItem = tabItems[1]
            if(myFavName.count != 0)
            {
            tabItem.badgeValue = "\(myFavName.count)"
            }
            else
            {
                tabItem.badgeValue = nil
            }
        }
      
        
       
        
        
        
        

        // Do any additional setup after loading the view.
    }
    override func viewWillAppear(_ animated: Bool) {
        if(myFavName.count == 0)
        {
            emptyLabel.isHidden = false
            favoriteInfoTableView.isHidden = true
        
        }
        else
        {
            emptyLabel.isHidden = true
            favoriteInfoTableView.isHidden = false
          
        }
        if let tabItems = tabBarController?.tabBar.items {
            // In this case we want to modify the badge number of the third tab:
            let tabItem = tabItems[1]
            if(myFavName.count != 0)
            {
            tabItem.badgeValue = "\(myFavName.count)"
            }
            else
            {
                tabItem.badgeValue = nil
            }
        }
        self.favoriteInfoTableView.reloadData()
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return myFavName.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "favoriteCustomTableViewCell", for: indexPath)as?
                favoriteCustomTableViewCell else {fatalError("Unable to run")}
        
        
        
        cell.favItem?.textColor = UIColor.black
        cell.favItem?.font = UIFont(name: "Chalkboard SE", size: 14)
        cell.favItem.adjustsFontSizeToFitWidth = true
        
        cell.favAddress?.textColor = UIColor.gray
        cell.favAddress?.font = UIFont(name: "Chalkboard SE", size: 14)
        cell.favAddress.adjustsFontSizeToFitWidth = true

        cell.favRate?.textColor = UIColor.black
        cell.favRate?.font = UIFont(name: "Chalkboard SE Bold", size: 14)
        cell.favRate?.textAlignment = .center
        
        
        cell.button.setTitle("", for: .normal)
        
        cell.favImage?.image = UIImage(named: "\(myFavName[indexPath.row].lowercased())")
        cell.favItem?.text = myFavName[indexPath.row].uppercased()
        
        cell.favAddress.text = "\(myFavAddress[indexPath.row])"
        cell.favRate.text = "₹ " + "\(myFavRate[indexPath.row])"
        cell.favImage?.backgroundColor = .gray
        cell.button.addTarget(self, action: #selector(deleteBtnAction(sender:)), for: .touchUpInside)
        cell.button.tag = indexPath.row
    
       
        
        return cell
    }
    
    @objc func deleteBtnAction(sender: UIButton)
    {
        myFavName.remove(at: sender.tag)
        myFavRate.remove(at: sender.tag)
        myFavAddress.remove(at: sender.tag)
        if let tabItems = tabBarController?.tabBar.items {
            // In this case we want to modify the badge number of the third tab:
            let tabItem = tabItems[1]
            if(myFavName.count != 0)
            {
            tabItem.badgeValue = "\(myFavName.count)"
            }
            else
            {
                tabItem.badgeValue = nil
            }
        }

        if(myFavName.count == 0)
        {
            emptyLabel.isHidden = false
            favoriteInfoTableView.isHidden = true
        
        }
        else
        {
            emptyLabel.isHidden = true
            favoriteInfoTableView.isHidden = false
          
        }
        favoriteInfoTableView.reloadData()
        
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let vc = storyboard?.instantiateViewController(withIdentifier: "ProductInfoViewController") as! ProductInfoViewController
        
        self.selectedProdName = "\(myFavName[indexPath.item])"
        vc.productArr = "myFavName"
        vc.ProdName = self.selectedProdName
        vc.productAddress = myFavAddress[indexPath.item]
        currentFavPrice = myFavRate[indexPath.item]
    
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 125
    }


}
