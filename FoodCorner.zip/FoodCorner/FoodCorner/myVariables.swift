//
//  myVariables.swift
//  FoodCorner
//
//  Created by Anilkumar on 24/06/22.
//

import Foundation
import UIKit


var myName = "Nishith"
var myUserName = "1"
var myPassword = "1"


var vegArr = ["onion masala dosa","spanakopita stuffed shells","idli","chapathi","friedrice","baked feta pasta"]
var vegRatingArr = ["3.5","5.0","2.5","4.1","3.8","4.9"]
var nvArr = ["burger","biriyani","fries","burrito","pizza","tuscan chicken pasta"]
var favArr = ["baked feta pasta","biriyani","friedrice","burrito","onion masala dosa"]
var favRatingArr = ["3.5","5.0","2.5","3.8","4.6"]
var favAddressArr = ["67-71 Dr Krishnasamy Mudaliyar Rd Unit No T17&18, Third Floor, Brookefelds Mall, Sukrawar Pettai, R.S. Puram, Coimbatore, Tamil Nadu 641001","11/5, Avinashi Rd, Peelamedu, Goldwins, Civil Aerodrome Post, Coimbatore, Tamil Nadu 641014","Brookfields Mall, Dr Krishnasamy Mudaliyar Rd, Puthiyavan Nagar, Sukrawar Pettai, R.S. Puram, Coimbatore, Tamil Nadu 641001","Brookfields Mall, Dr Krishnasamy Mudaliyar Rd, Puthiyavan Nagar, Sukrawar Pettai, R.S. Puram, Coimbatore, Tamil Nadu 641001","No. 1391, Avinashi Rd, next to Aryaas Hotel, Peelamedu, Masakalipalayam, Coimbatore, Tamil Nadu 641004"]
var vegAddressArr = ["67-71 Dr Krishnasamy Mudaliyar Rd Unit No T17&18, Third Floor, Brookefelds Mall, Sukrawar Pettai, R.S. Puram, Coimbatore, Tamil Nadu 641001","11/5, Avinashi Rd, Peelamedu, Goldwins, Civil Aerodrome Post, Coimbatore, Tamil Nadu 641014","Brookfields Mall, Dr Krishnasamy Mudaliyar Rd, Puthiyavan Nagar, Sukrawar Pettai, R.S. Puram, Coimbatore, Tamil Nadu 641001","Brookfields Mall, Dr Krishnasamy Mudaliyar Rd, Puthiyavan Nagar, Sukrawar Pettai, R.S. Puram, Coimbatore, Tamil Nadu 641001","No. 1391, Avinashi Rd, next to Aryaas Hotel, Peelamedu, Masakalipalayam, Coimbatore, Tamil Nadu 641004","11/5, Avinashi Rd, Peelamedu, Goldwins, Civil Aerodrome Post, Coimbatore, Tamil Nadu 641014"]
var nvAddressArr = ["67-71 Dr Krishnasamy Mudaliyar Rd Unit No T17&18, Third Floor, Brookefelds Mall, Sukrawar Pettai, R.S. Puram, Coimbatore, Tamil Nadu 641001","11/5, Avinashi Rd, Peelamedu, Goldwins, Civil Aerodrome Post, Coimbatore, Tamil Nadu 641014","Brookfields Mall, Dr Krishnasamy Mudaliyar Rd, Puthiyavan Nagar, Sukrawar Pettai, R.S. Puram, Coimbatore, Tamil Nadu 641001","Brookfields Mall, Dr Krishnasamy Mudaliyar Rd, Puthiyavan Nagar, Sukrawar Pettai, R.S. Puram, Coimbatore, Tamil Nadu 641001","No. 1391, Avinashi Rd, next to Aryaas Hotel, Peelamedu, Masakalipalayam, Coimbatore, Tamil Nadu 641004","67-71 Dr Krishnasamy Mudaliyar Rd Unit No T17&18, Third Floor, Brookefelds Mall, Sukrawar Pettai, R.S. Puram, Coimbatore, Tamil Nadu 641001"]



var vegPrice = ["onion masala dosa" : 130.0,"spanakopita stuffed shells" : 230.0,"idli" : 40.0,"chapathi" : 25.0,"friedrice" : 160.0,"baked feta pasta" : 200.0]
var nvPrice = ["burger" : 100.0,"biriyani" : 120.0,"fries" : 60.0,"burrito" : 140.0,"pizza" : 330.0,"tuscan chicken pasta" : 240.0]


var myCartName = [String]()
var myFavName = [String]()
var myFavRate = [Double]()
var myFavAddress = [String]()
var currentFavPrice = 0.0

var MyCartAmt = [Double]()

var quanti = [Int]()

var imageHeight1 = 0.0
var imageHeight0 = 0.0



var myCartAddress = [String]()




