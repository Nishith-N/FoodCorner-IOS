//
//  CartViewController.swift
//  FoodCorner
//
//  Created by Anilkumar on 06/07/22.
//

import UIKit

class CartViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    var totalCart = 0.0

    @IBOutlet weak var totalAmount: UILabel!
    @IBOutlet weak var emptyCartLabel: UILabel!
    @IBOutlet weak var placeOrderBtn: UIButton!
    @IBOutlet weak var placeorderBackView: UIView!
    @IBOutlet weak var cartTableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        for val in MyCartAmt
        {
            totalCart += val
        }
        
        cartTableView.delegate = self
        cartTableView.dataSource = self
        
        placeorderBackView.layer.shadowColor = UIColor.lightGray.cgColor
        placeorderBackView.layer.shadowOpacity = 10
        placeorderBackView.layer.shadowOffset = CGSize.zero
        placeorderBackView.layer.shadowRadius = 10
        placeorderBackView.layer.cornerRadius = 10.0
        placeOrderBtn.layer.cornerRadius = 10.0
        
        
        
        emptyCartLabel.topAnchor.constraint(equalTo: view.topAnchor, constant: (UIScreen.main.bounds.height/2)-50).isActive = true
        emptyCartLabel.heightAnchor.constraint(equalToConstant: 100).isActive = true
        emptyCartLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20).isActive = true
        emptyCartLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20).isActive = true
        emptyCartLabel.translatesAutoresizingMaskIntoConstraints = false
        totalAmount.text = "Total ₹ " + "\(totalCart)"
        if(myCartName.count == 0)
        {
            emptyCartLabel.isHidden = false
            cartTableView.isHidden = true
            placeOrderBtn.isEnabled = false
        }
        else
        {
            emptyCartLabel.isHidden = true
            cartTableView.isHidden = false
            placeOrderBtn.isEnabled = true
        }
        
        
        

        // Do any additional setup after loading the view.
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return myCartName.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "cartCustomTableViewCell", for: indexPath)as?
                cartCustomTableViewCell else {fatalError("Unable to run")}
        
        
        
        cell.favImage?.contentMode = .scaleAspectFit
        
        cell.favItem?.textColor = UIColor.black
        cell.favItem?.font = UIFont(name: "Chalkboard SE", size: 14)
        cell.favItem.adjustsFontSizeToFitWidth = true
        cell.favItem.numberOfLines = 0
        
        cell.favAddress?.textColor = UIColor.gray
        cell.favAddress?.font = UIFont(name: "Chalkboard SE", size: 14)
        cell.favAddress.adjustsFontSizeToFitWidth = true
        
        cell.favRate?.textColor = UIColor.red
        cell.favRate?.font = UIFont(name: "Chalkboard SE Bold", size: 14)
        cell.favRate?.textAlignment = .center
        
        cell.backgroundColor = .black
        
        cell.button.setTitle("", for: .normal)

        
        cell.favImage?.image = UIImage(named: "\(myCartName[indexPath.row])")
        cell.favItem?.text = myCartName[indexPath.row].uppercased() + "  x" + "\(quanti[indexPath.row])"
        cell.favAddress?.text = "\(myCartAddress[indexPath.row])"
        cell.favRate?.text = "₹ " + "\(MyCartAmt[indexPath.row])"
        cell.favImage?.backgroundColor = .gray
        cell.button.addTarget(self, action: #selector(deleteBtnAction(sender:)), for: .touchUpInside)
        cell.button.tag = indexPath.row
        
        
        
        
        
          
        
        return cell
    }
    
    @objc func deleteBtnAction(sender: UIButton)
    {
        myCartName.remove(at: sender.tag)
        MyCartAmt.remove(at: sender.tag)
        myCartAddress.remove(at: sender.tag)
        quanti.remove(at: sender.tag)
        if(myCartName.count == 0)
        {
            emptyCartLabel.isHidden = false
            cartTableView.isHidden = true
            placeOrderBtn.isEnabled = false
        }
        else
        {
            emptyCartLabel.isHidden = true
            cartTableView.isHidden = false
            placeOrderBtn.isEnabled = true
        }
        totalCart = 0.0
        for val in MyCartAmt
        {
            totalCart += val
        }
        
        
        totalAmount.text = "Total ₹ " + "\(totalCart)"
        cartTableView.reloadData()
        
    }
//    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
//        let vc = storyboard?.instantiateViewController(withIdentifier: "ProductInfoViewController") as! ProductInfoViewController
//
//        self.selectedProdName = "\(favArr[indexPath.item])"
//        vc.productArr = "favArr"
//        vc.ProdName = self.selectedProdName
//
//        self.navigationController?.pushViewController(vc, animated: true)
//    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 120
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
