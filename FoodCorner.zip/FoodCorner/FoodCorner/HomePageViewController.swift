import UIKit

let uiwidth = UIScreen.main.bounds.width

var selectedProdName = ""



class HomePageViewController: UIViewController,UICollectionViewDelegate,UICollectionViewDataSource, headerDelegate,SecondheaderDelegate{
    func didSelect1() {
     
        
        let vc = storyboard?.instantiateViewController(withIdentifier: "fastFoodsInfoViewController") as! fastFoodsInfoViewController
        self.navigationController?.pushViewController(vc, animated: true)
        
        
        
    }
    func didSelect2() {
     
        
        let vc = storyboard?.instantiateViewController(withIdentifier: "vegInfoViewController") as! vegInfoViewController
        self.navigationController?.pushViewController(vc, animated: true)
        
        
        
    }
    
    var selectedProdName = ""

    
    
    
    
    @IBOutlet weak var cartBtn: UIBarButtonItem!
    @IBOutlet var homeCollectionView: UICollectionView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        self.navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.font: UIFont(name: "Chalkboard SE Bold", size: 20)!]
        
        
       
        
        
        
        setAspectRatio()
       
        self.navigationItem.setHidesBackButton(true, animated: true)
        homeCollectionView.collectionViewLayout = generateLayout()
        homeCollectionView.delegate = self
        homeCollectionView.dataSource = self
        
        homeCollectionView.register(FirstHeaderCollectionReusableView.self, forSupplementaryViewOfKind: HomePageViewController.firstID, withReuseIdentifier: headerId)
        homeCollectionView.register(SecondHeaderCollectionReusableView.self, forSupplementaryViewOfKind: HomePageViewController.secondID, withReuseIdentifier: headerId)
//                setTimer()
        
       

        // Do any additional setup after loading the view.
    }
    
    
    func setTimer() {
         let _ = Timer.scheduledTimer(timeInterval: 2.0, target: self, selector: #selector(autoScroll), userInfo: nil, repeats: true)
    }
    var x = 1
    
    
    @objc func autoScroll() {
        if self.x < 4 {
          let indexPath = IndexPath(item: x, section: 0)
            self.homeCollectionView.scrollToItem(at: indexPath, at: .centeredVertically, animated: true)
          self.x = self.x + 1
           
           


        }else{
          self.x = 0
          self.homeCollectionView.scrollToItem(at: IndexPath(item: 0, section: 0), at: .bottom, animated: true)
        }
    }

    
    func generateLayout() -> UICollectionViewLayout {
            return UICollectionViewCompositionalLayout { (sectionNumber, env) -> NSCollectionLayoutSection? in
                
                switch sectionNumber {
                    
                case 0: return self.zeroLayoutSection()
                case 1: return self.firstLayoutSection()
                case 2: return self.secondLayoutSection()
                default: return self.zeroLayoutSection()
                }
            }
        
    }
    
    func setAspectRatio()
    {
        imageHeight1 = UIScreen.main.bounds.height*(260/926)
        imageHeight0 = UIScreen.main.bounds.height*(340/926)
    }
    
    
    private func zeroLayoutSection() -> NSCollectionLayoutSection {
        let item = NSCollectionLayoutItem.init(layoutSize: .init(widthDimension: .fractionalWidth(0.96), heightDimension: .fractionalHeight(1)))
        let group = NSCollectionLayoutGroup.horizontal(layoutSize: .init(widthDimension: .fractionalWidth(0.96), heightDimension: .absolute(imageHeight0)), subitems: [item])
        let section = NSCollectionLayoutSection(group: group)
        section.orthogonalScrollingBehavior = .groupPaging
        
//        group.contentInsets.trailing = 16
        section.contentInsets.bottom = 16
        section.contentInsets.top = 30
        section.contentInsets.trailing = 16
        section.contentInsets.leading = 16
        
        
        
        return section
    
    }
    private func firstLayoutSection() -> NSCollectionLayoutSection {
        let item = NSCollectionLayoutItem.init(layoutSize: .init(widthDimension: .fractionalWidth(1), heightDimension: .fractionalHeight(1)))
        let group = NSCollectionLayoutGroup.horizontal(layoutSize: .init(widthDimension: .fractionalWidth(0.75), heightDimension: .absolute(imageHeight1)), subitems: [item])
        group.contentInsets.trailing = 16
        let section = NSCollectionLayoutSection(group: group)
        section.orthogonalScrollingBehavior = .continuous
        section.contentInsets.leading = 16
        section.contentInsets.top = 16
        section.contentInsets.bottom = 20
        section.boundarySupplementaryItems = [
            .init(layoutSize: .init(widthDimension: .fractionalWidth(1), heightDimension: .absolute(50)), elementKind: HomePageViewController.firstID, alignment: .topLeading)
        ]
        
        return section
       
    }
    private func secondLayoutSection() -> NSCollectionLayoutSection {
        
        let item = NSCollectionLayoutItem.init(layoutSize: .init(widthDimension: .fractionalWidth(1), heightDimension: .fractionalHeight(1)))
        let group = NSCollectionLayoutGroup.horizontal(layoutSize: .init(widthDimension: .fractionalWidth(0.75), heightDimension: .absolute(imageHeight1)), subitems: [item])
        group.contentInsets.trailing = 16
        let section = NSCollectionLayoutSection(group: group)
        section.orthogonalScrollingBehavior = .continuous
        section.contentInsets.leading = 16
        section.contentInsets.bottom = 16
        section.boundarySupplementaryItems = [
            .init(layoutSize: .init(widthDimension: .fractionalWidth(1), heightDimension: .absolute(50)), elementKind: HomePageViewController.secondID, alignment: .topLeading)
        ]
        return section
    
       
    }
    let headerId = "headerId"
    static let firstID = "firstID"
    static let secondID = "secondID"
    
    
    

    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 3
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let vc = storyboard?.instantiateViewController(withIdentifier: "ProductInfoViewController") as! ProductInfoViewController
        if indexPath.section == 0
        {
            self.selectedProdName = "\(nvArr[indexPath.item])"
            vc.productArr = "nvArr"
            vc.productAddress = nvAddressArr[indexPath.item]
        
            
            
        }
        else if indexPath.section == 1
        {
            self.selectedProdName = "\(nvArr[indexPath.item])"
            vc.productArr = "nvArr"
            vc.productAddress = nvAddressArr[indexPath.item]
        }
        else if indexPath.section == 2
        {
            self.selectedProdName = "\(vegArr[indexPath.item])"
            vc.productArr = "vegArr"
            vc.productAddress = vegAddressArr[indexPath.item]
        }
        vc.ProdName = self.selectedProdName
    
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if section == 0 {
            return 3
        }
        else if section == 1
        {
            return nvArr.count
        }
        else if section == 2
        {
            return vegArr.count
        }
        return 5
    }
    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
        
        
        
        if indexPath.section == 1
        {
            let header = collectionView.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: headerId, for: indexPath) as! FirstHeaderCollectionReusableView
            header.delegate = self
            header.fastFoodlbl.text = "Non Veg"
            return header
        
        }
        else/* if indexPath.section == 2*/
        {
            let header = collectionView.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: headerId, for: indexPath) as! SecondHeaderCollectionReusableView
            header.delegate = self
            header.fastFoodlbl.text = "Veg"
            return header
        }
           
        
       
        
        
        
        
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "myCustomCollectionViewCell", for: indexPath) as! myCustomCollectionViewCell
        if indexPath.section == 0{
        cell.MyImage.image = UIImage(named: "\(nvArr[indexPath.row])")
            cell.contentView.layer.cornerRadius = 20.0
            cell.myLabel.text = "\(nvArr[indexPath.row])".capitalized
            cell.myLabel.adjustsFontSizeToFitWidth = true
            cell.contentView.clipsToBounds = true
            
           
        }
        else if indexPath.section == 1{
            
        cell.MyImage.image = UIImage(named: "\(nvArr[indexPath.row])")
            cell.contentView.layer.cornerRadius = 20.0
            cell.contentView.clipsToBounds = true
            cell.myLabel.text = "\(nvArr[indexPath.row])".capitalized
            cell.myLabel.adjustsFontSizeToFitWidth = true
            
            cell.MyImage.leadingAnchor.constraint(equalTo: cell.contentView.leadingAnchor, constant: 0).isActive = true
            cell.MyImage.trailingAnchor.constraint(equalTo: cell.contentView.trailingAnchor, constant: 0).isActive = true
            cell.MyImage.translatesAutoresizingMaskIntoConstraints = false
            
            cell.MyImage.topAnchor.constraint(equalTo: cell.contentView.topAnchor, constant: 0).isActive = true
            cell.MyImage.bottomAnchor.constraint(equalTo: cell.contentView.bottomAnchor, constant: 0).isActive = true
            cell.MyImage.heightAnchor.constraint(equalToConstant: 200).isActive = true
            
        }
        
        else if indexPath.section == 2{
            cell.contentView.layer.cornerRadius = 20.0
            cell.contentView.clipsToBounds = true
           
            cell.MyImage.image = UIImage(named: "\(vegArr[indexPath.row])")
            cell.myLabel.text = "\(vegArr[indexPath.row])".capitalized
            
            cell.myLabel.adjustsFontSizeToFitWidth = true
            
            cell.MyImage.leadingAnchor.constraint(equalTo: cell.contentView.leadingAnchor, constant: 0).isActive = true
            cell.MyImage.trailingAnchor.constraint(equalTo: cell.contentView.trailingAnchor, constant: 0).isActive = true
            cell.MyImage.translatesAutoresizingMaskIntoConstraints = false
            cell.MyImage.bottomAnchor.constraint(equalTo: cell.contentView.bottomAnchor, constant: 0).isActive = true
            cell.MyImage.heightAnchor.constraint(equalToConstant: 200).isActive = true
            
        }
    
        return cell
    }
    
    

}



