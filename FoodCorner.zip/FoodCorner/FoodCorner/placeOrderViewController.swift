//
//  placeOrderViewController.swift
//  FoodCorner
//
//  Created by Anilkumar on 07/07/22.
//

import UIKit
import GoogleMaps

class placeOrderViewController: UIViewController,CLLocationManagerDelegate,GMSMapViewDelegate {
    
    var totalCart = 0.0
    
    @IBOutlet weak var payBtn: UIButton!
    private let locationManager = CLLocationManager()

    @IBOutlet weak var amountLabel: UILabel!
    @IBOutlet weak var myMapView: GMSMapView!
    
    @IBOutlet weak var myMapLabel: UITextView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        for val in MyCartAmt
        {
            totalCart += val
        }
        
                

        
        payBtn.layer.shadowColor = UIColor.lightGray.cgColor
        payBtn.layer.shadowOpacity = 10
        payBtn.layer.shadowOffset = CGSize.zero
        payBtn.layer.shadowRadius = 10
        payBtn.layer.cornerRadius = 10.0
        
        
    
        payBtn.setTitle("Pay  ₹" + "\(totalCart)", for: .normal)
        payBtn.setTitleColor(.black, for: .normal)
    
        
        

    
        
        locationManager.delegate = self
        locationManager.requestWhenInUseAuthorization()
        myMapView.delegate = self
        
        amountLabel.text = "₹ " + "\(totalCart)"

        // Do any additional setup after loading the view.
    }
    
    func mapView(_ mapView: GMSMapView, idleAt position: GMSCameraPosition) {
      reverseGeocodeCoordinate(position.target)
    }
    
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
      // 3
      guard status == .authorizedWhenInUse else {
        return
      }
      // 4
      locationManager.startUpdatingLocation()
        
      //5
      myMapView.isMyLocationEnabled = true
      myMapView.settings.myLocationButton = true
    }
    
    private func reverseGeocodeCoordinate(_ coordinate: CLLocationCoordinate2D) {
        
      // 1
      let geocoder = GMSGeocoder()
        
        
        let labelHeight = self.myMapLabel.intrinsicContentSize.height
        self.myMapView.padding = UIEdgeInsets(top: self.view.safeAreaInsets.top, left: 0,
                                            bottom: labelHeight, right: 0)
      // 2
      geocoder.reverseGeocodeCoordinate(coordinate) { response, error in
        guard let address = response?.firstResult(), let lines = address.lines else {
          return
        }
          
        // 3
        self.myMapLabel.text = lines.joined(separator: "\n")
          
        // 4
        UIView.animate(withDuration: 0.25) {
          self.view.layoutIfNeeded()
        }
      }
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
      guard let location = locations.first else {
        return
      }
        
      // 7
      myMapView.camera = GMSCameraPosition(target: location.coordinate, zoom: 15, bearing: 0, viewingAngle: 0)
        
      // 8
      locationManager.stopUpdatingLocation()
    }
}
