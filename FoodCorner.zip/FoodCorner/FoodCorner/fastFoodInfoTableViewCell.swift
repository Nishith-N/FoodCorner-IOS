//
//  fastFoodInfoTableViewCell.swift
//  FoodCorner
//
//  Created by Byot on 02/07/22.
//

import UIKit

class fastFoodInfoTableViewCell: UITableViewCell {
    
    let screenSize = UIScreen.main.bounds.size
    lazy var backView: UIView = {
        let view = UIView(frame: CGRect(x: 0, y: 0, width: screenSize.width, height: 100))
        
        return view
    }()
    lazy var fastFoodImage: UIImageView = {
       let pimage = UIImageView(/*frame: CGRect(x: 15, y: 10, width: 50, height: 50)*/)
        pimage.image = UIImage(named: "prof-1")
        pimage.translatesAutoresizingMaskIntoConstraints = false
        pimage.contentMode = .scaleAspectFit
      
        
        return pimage
    }()

    lazy var fastFoodName: UILabel! = {
        let contact = UILabel(frame: CGRect(x: 120, y: 25, width: (screenSize.width*3/4)-(screenSize.width*1/4), height: 30))
        contact.textColor = UIColor.black
        contact.font = UIFont(name: "Chalkboard SE", size: 14)
        
     
        return contact
    }()
    
    lazy var fastFoodAddress: UILabel = {
        let msge = UILabel(frame: CGRect(x: 120, y: 55, width: 150, height: 30))
        msge.textColor = UIColor.gray
        msge.font = UIFont(name: "Chalkboard SE", size: 14)
        
        return msge
    }()

    lazy var fastFoodRate: UILabel = {
        let time = UILabel(frame: CGRect(x: (screenSize.width*1/2), y:25, width: 50, height: 30))
        time.textColor = UIColor.black
        time.font = UIFont(name: "Chalkboard SE Bold", size: 14)
        time.backgroundColor = .orange
        time.textAlignment = .center
       
        return time
    }()

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        addSubview(backView)
        backView.addSubview(fastFoodImage)
        backView.addSubview(fastFoodName)
        backView.addSubview(fastFoodAddress)
        backView.addSubview(fastFoodRate)
        
        fastFoodImage.leadingAnchor.constraint(equalTo: self.backView.leadingAnchor, constant: 10).isActive = true
        fastFoodImage.widthAnchor.constraint(equalToConstant: 100).isActive = true
        fastFoodImage.heightAnchor.constraint(equalToConstant: 100).isActive = true
        fastFoodImage.topAnchor.constraint(equalTo: self.backView.topAnchor, constant: 10).isActive = true
        
        fastFoodName.leadingAnchor.constraint(equalTo: self.fastFoodImage.trailingAnchor, constant: 10).isActive = true
        fastFoodName.topAnchor.constraint(equalTo: self.backView.topAnchor, constant: 10).isActive = true
        fastFoodName.heightAnchor.constraint(equalToConstant: 20).isActive = true
        fastFoodName.translatesAutoresizingMaskIntoConstraints = false
        
        fastFoodAddress.leadingAnchor.constraint(equalTo: self.fastFoodImage.trailingAnchor, constant: 5).isActive = true
        fastFoodAddress.topAnchor.constraint(equalTo: self.fastFoodName.bottomAnchor, constant: 10).isActive = true
        fastFoodAddress.trailingAnchor.constraint(equalTo: self.fastFoodRate.leadingAnchor, constant: -5).isActive = true
        fastFoodAddress.bottomAnchor.constraint(equalTo: self.backView.bottomAnchor, constant: 0).isActive = true
        fastFoodAddress.translatesAutoresizingMaskIntoConstraints = false
        fastFoodAddress.adjustsFontSizeToFitWidth = true
        fastFoodAddress.numberOfLines = 0
        
        fastFoodRate.trailingAnchor.constraint(equalTo: self.backView.trailingAnchor, constant: -8).isActive = true
        fastFoodRate.widthAnchor.constraint(equalToConstant: 40).isActive = true
        fastFoodRate.textAlignment = .center
        fastFoodRate.topAnchor.constraint(equalTo: backView.topAnchor, constant: 10).isActive = true
        fastFoodRate.translatesAutoresizingMaskIntoConstraints = false
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

}
