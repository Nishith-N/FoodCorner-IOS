//
//  myCustomCollectionViewCell.swift
//  FoodCorner
//
//  Created by Byot on 24/06/22.
//

import UIKit

class myCustomCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet var MyImage: UIImageView!
    
    @IBOutlet weak var myLabel: UILabel!
    @IBOutlet weak var myView: UIView!
}
