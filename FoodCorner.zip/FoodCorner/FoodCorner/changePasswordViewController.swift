//
//  changePasswordViewController.swift
//  FoodCorner
//
//  Created by Anilkumar on 07/07/22.
//

import UIKit

class changePasswordViewController: UIViewController,UITextFieldDelegate {
    let thickness: CGFloat = 2.0
    
    @IBOutlet weak var confirmTextField: UITextField!
    
    @IBOutlet weak var cancelBtn: UIButton!
    @IBOutlet weak var changePasswordBtn: UIButton!
    @IBOutlet weak var passwordTextField: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        confirmTextField.delegate = self
        passwordTextField.delegate = self
        
        self.changePasswordBtn.layer.cornerRadius = 15.0
        self.changePasswordBtn.clipsToBounds = true
        
        passwordTextField.layer.cornerRadius = 5.0
        passwordTextField.clipsToBounds = true
        confirmTextField.layer.cornerRadius = 5.0
        confirmTextField.clipsToBounds = true
        
        passwordTextField.isSecureTextEntry = true
        confirmTextField.isSecureTextEntry = true
        
        passwordTextField.keyboardType = .emailAddress
        confirmTextField.keyboardType = .emailAddress
        
        setGradientBackground()
        AddBottomBorders()
    }
        
        func AddBottomBorders() {
            let bottomBorderPassword = CALayer()
             bottomBorderPassword.frame = CGRect(x:0, y: self.passwordTextField.frame.size.height - thickness, width: self.passwordTextField.frame.width, height:thickness)
            bottomBorderPassword.backgroundColor = UIColor.black.cgColor
            
            let bottomBorderCnfrm = CALayer()
             bottomBorderCnfrm.frame = CGRect(x:0, y: self.passwordTextField.frame.size.height - thickness, width: self.passwordTextField.frame.width, height:thickness)
            bottomBorderCnfrm.backgroundColor = UIColor.black.cgColor
            
            passwordTextField.layer.addSublayer(bottomBorderPassword)
            confirmTextField.layer.addSublayer(bottomBorderCnfrm)
            
        }
        
        func setGradientBackground() {
            let colorTop = UIColor(red: 254.0/255.0, green: 208.0/255.0, blue: 79.0/255.0, alpha: 1.0).cgColor
            let colormiddle =  UIColor(red: 255.0/255.0, green: 255.0/255.0, blue: 255.0/255.0, alpha: 1.0).cgColor
            let gradientLayer = CAGradientLayer()
            
            gradientLayer.colors = [colorTop,colormiddle]
            gradientLayer.locations = [0.0, 1.0]
            gradientLayer.frame = self.view.bounds
                    
            self.view.layer.insertSublayer(gradientLayer, at:0)
        }
        
        func textFieldDidBeginEditing(_ textField: UITextField) {
            
            if textField == self.passwordTextField
            {
                let bottomBorderPassword = CALayer()
                bottomBorderPassword.frame = CGRect(x:0, y: self.passwordTextField.frame.size.height - thickness, width: self.passwordTextField.frame.width, height:thickness)
               bottomBorderPassword.backgroundColor = UIColor.black.cgColor
                passwordTextField.layer.addSublayer(bottomBorderPassword)
                
                self.passwordTextField.becomeFirstResponder()
            }
            if textField == self.confirmTextField
            {
                let bottomBorderCnfrm = CALayer()
                 bottomBorderCnfrm.frame = CGRect(x:0, y: self.passwordTextField.frame.size.height - thickness, width: self.passwordTextField.frame.width, height:thickness)
                bottomBorderCnfrm.backgroundColor = UIColor.black.cgColor
                confirmTextField.layer.addSublayer(bottomBorderCnfrm)
                
                self.confirmTextField.becomeFirstResponder()
            }
        }
        func textFieldDidEndEditing(_ textField: UITextField) {
            if textField == self.passwordTextField
            {
                if textField.text == ""
                {
                let bottomBorderPassword = CALayer()
                bottomBorderPassword.frame = CGRect(x:0, y: self.passwordTextField.frame.size.height - thickness, width: self.passwordTextField.frame.width, height:thickness)
               bottomBorderPassword.backgroundColor = UIColor.red.cgColor
                passwordTextField.layer.addSublayer(bottomBorderPassword)
                }
            }
            
            if textField == self.confirmTextField
            {
                if textField.text == ""
                {
                let bottomBorderCnfrm = CALayer()
                 bottomBorderCnfrm.frame = CGRect(x:0, y: self.confirmTextField.frame.size.height - thickness, width: self.confirmTextField.frame.width, height:thickness)
                bottomBorderCnfrm.backgroundColor = UIColor.red.cgColor
                confirmTextField.layer.addSublayer(bottomBorderCnfrm)
                }
            }
            
        }
        func textFieldShouldReturn(_ textField: UITextField) -> Bool {
            if textField == self.passwordTextField
            {
                self.passwordTextField.resignFirstResponder()
            }
            if textField == self.confirmTextField
            {
                self.confirmTextField.resignFirstResponder()
            }
            return true
            
        }

        // Do any additional setup after loading the view.
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

    @IBAction func changePasswordBtnAction(_ sender: Any) {
        if (passwordTextField.text == "" || confirmTextField.text == "")
        {
            let alertController = UIAlertController(title: "Error", message:
                    "One or more fields are Empty!", preferredStyle: .alert)
                alertController.addAction(UIAlertAction(title: "Try Again", style: .destructive))
            self.present(alertController, animated: true, completion: nil)
        if passwordTextField.text == ""
        {
            
            let bottomBorderPassword = CALayer()
            bottomBorderPassword.frame = CGRect(x:0, y: self.passwordTextField.frame.size.height - thickness, width: self.passwordTextField.frame.width, height:thickness)
           bottomBorderPassword.backgroundColor = UIColor.red.cgColor
            passwordTextField.layer.addSublayer(bottomBorderPassword)
        }
        if confirmTextField.text == ""
        {
            let bottomBorderCnfrm = CALayer()
             bottomBorderCnfrm.frame = CGRect(x:0, y: self.confirmTextField.frame.size.height - thickness, width: self.confirmTextField.frame.width, height:thickness)
            bottomBorderCnfrm.backgroundColor = UIColor.red.cgColor
            confirmTextField.layer.addSublayer(bottomBorderCnfrm)

        }
        }
        else
        {
            if passwordTextField.text == confirmTextField.text
            {
                
                let vc = storyboard?.instantiateViewController(withIdentifier: "LoginViewController") as! ViewController
                self.navigationController?.pushViewController(vc, animated: true)
                
                myPassword = passwordTextField.text!
                
                let alertController = UIAlertController(title: "Password updated successfully!!", message:
                        "Login to continue", preferredStyle: .alert)
                    alertController.addAction(UIAlertAction(title: "OK", style: .default))

                    self.present(alertController, animated: true, completion: nil)
                
            
            
            }
            
            else
            {
                let alertController = UIAlertController(title: "Error", message:
                        "Check Password and Confirm Password!", preferredStyle: .alert)
                    alertController.addAction(UIAlertAction(title: "Dismiss", style: .destructive))

                    self.present(alertController, animated: true, completion: nil)
            }
        }
            
        
    }
    @IBAction func cancelBtnAction(_ sender: UIButton) {
        
        self.navigationController?.popViewController(animated: true)
    }
}
