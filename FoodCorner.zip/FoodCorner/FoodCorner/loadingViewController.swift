//
//  loadingViewController.swift
//  FoodCorner
//
//  Created by Anilkumar on 08/07/22.
//

import UIKit
import Lottie
class loadingViewController: UIViewController {



    @IBOutlet weak var bufferView: AnimationView!
    @IBOutlet weak var loadingView: AnimationView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
//        loadingView.contentMode = .scaleAspectFit
          
          // 2. Set animation loop mode
          
        loadingView.loopMode = .loop
          
          // 3. Adjust animation speed
          
        loadingView.animationSpeed = 1
          
          // 4. Play animation
        loadingView.play()
        
        bufferView.loopMode = .loop
          
          // 3. Adjust animation speed
          
        bufferView.animationSpeed = 1
          
          // 4. Play animation
        bufferView.play()
        
        loadingView.topAnchor.constraint(equalTo: view.topAnchor, constant: (UIScreen.main.bounds.height/2)-150).isActive = true
        loadingView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20).isActive = true
        loadingView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20).isActive = true
        loadingView.heightAnchor.constraint(equalToConstant: 200).isActive = true
        loadingView.translatesAutoresizingMaskIntoConstraints = false
        
        bufferView.topAnchor.constraint(equalTo: loadingView.bottomAnchor, constant: 1).isActive = true
        bufferView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20).isActive = true
        bufferView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20).isActive = true
        bufferView.heightAnchor.constraint(equalToConstant: 100).isActive = true
        bufferView.translatesAutoresizingMaskIntoConstraints = false
        
        Timer.scheduledTimer(timeInterval: 4, target: self, selector: #selector(showVC), userInfo: nil, repeats: false)

        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.tabBarController?.tabBar.isHidden = true
        navigationController?.setNavigationBarHidden(true, animated: animated)
    }

   
    @objc func showVC() {
        
        let vc = storyboard?.instantiateViewController(withIdentifier: "tabBar") as! tabBar
                    vc.selectedViewController = vc.viewControllers?[0]
                self.navigationController?.pushViewController(vc, animated: true)
        //navigate to your desired VC
    }
    
    
    
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
