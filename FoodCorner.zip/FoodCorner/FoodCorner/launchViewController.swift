//
//  launchViewController.swift
//  FoodCorner
//
//  Created by Anilkumar on 08/07/22.
//

import UIKit
import Lottie

class launchViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
 
        
        

        // Do any additional setup after loading the view.
    }
    


}
