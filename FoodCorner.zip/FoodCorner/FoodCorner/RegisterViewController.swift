import UIKit

class RegisterViewController: UIViewController,UITextFieldDelegate {
    
    let thickness: CGFloat = 2.0
    
    @IBOutlet weak var backView: UIView!
    @IBOutlet var usernameTextField: UITextField!
    @IBOutlet var confirmTextField: UITextField!
    @IBOutlet var passwordTextField: UITextField!
    @IBOutlet var customerNameTextField: UITextField!
    @IBOutlet var registerBtn: UIButton!
    
    @IBOutlet weak var cancelBtn: UIButton!
    @IBOutlet weak var bgView: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.hideKeyboardWhenTappedAround()
        
        customerNameTextField.delegate = self
        usernameTextField.delegate = self
        passwordTextField.delegate = self
        confirmTextField.delegate = self
        
        self.registerBtn.layer.cornerRadius = 15.0
        self.registerBtn.clipsToBounds = true
        self.registerBtn.addTarget(self, action: #selector(registerAction(sender:)), for: .touchUpInside)
        
        cancelBtn.layer.cornerRadius = 15.0
        cancelBtn.clipsToBounds = true
        
        cancelBtn.setTitle("Have an account? Login", for: .normal)
        cancelBtn.setTitleColor(.darkGray, for: .normal)
        
        
        usernameTextField.layer.cornerRadius = 5.0
        usernameTextField.clipsToBounds = true
        passwordTextField.layer.cornerRadius = 5.0
        passwordTextField.clipsToBounds = true
        confirmTextField.layer.cornerRadius = 5.0
        confirmTextField.clipsToBounds = true
        customerNameTextField.layer.cornerRadius = 5.0
        customerNameTextField.clipsToBounds = true
        
        passwordTextField.isSecureTextEntry = true
        confirmTextField.isSecureTextEntry = true
        
        usernameTextField.keyboardType = .emailAddress
        passwordTextField.keyboardType = .emailAddress
        confirmTextField.keyboardType = .emailAddress
        bgView.backgroundColor = UIColor(red: 254.0/255.0, green: 208.0/255.0, blue: 79.0/255.0, alpha: 1.0)
        
        setGradientBackgroundBack()
//        setGradientBackgroundView()
        AddBottomBorders()

    }
    
    
    @objc func registerAction(sender: UIButton)
    {
        
        
        if (customerNameTextField.text == "" || usernameTextField.text == "" || passwordTextField.text == "" || confirmTextField.text == "")
        {
            let alertController = UIAlertController(title: "Error", message:
                    "One or more fields are Empty!", preferredStyle: .alert)
                alertController.addAction(UIAlertAction(title: "Try Again", style: .destructive))

                self.present(alertController, animated: true, completion: nil)
            
            if customerNameTextField.text == ""
            {
                let bottomBorderName = CALayer()
                 bottomBorderName.frame = CGRect(x:0, y: self.customerNameTextField.frame.size.height - thickness, width: self.customerNameTextField.frame.width, height:thickness)
                bottomBorderName.backgroundColor = UIColor.red.cgColor
                customerNameTextField.layer.addSublayer(bottomBorderName)
            }
            if usernameTextField.text == ""
            {
                let bottomBorderUsername = CALayer()
                 bottomBorderUsername.frame = CGRect(x:0, y: self.usernameTextField.frame.size.height - thickness, width: self.usernameTextField.frame.width, height:thickness)
                bottomBorderUsername.backgroundColor = UIColor.red.cgColor
                usernameTextField.layer.addSublayer(bottomBorderUsername)
            }
            if passwordTextField.text == ""
            {
                let bottomBorderPassword = CALayer()
                bottomBorderPassword.frame = CGRect(x:0, y: self.passwordTextField.frame.size.height - thickness, width: self.passwordTextField.frame.width, height:thickness)
               bottomBorderPassword.backgroundColor = UIColor.red.cgColor
                passwordTextField.layer.addSublayer(bottomBorderPassword)
            }
            if confirmTextField.text == ""
            {
                let bottomBorderCnfrm = CALayer()
                 bottomBorderCnfrm.frame = CGRect(x:0, y: self.customerNameTextField.frame.size.height - thickness, width: self.customerNameTextField.frame.width, height:thickness)
                bottomBorderCnfrm.backgroundColor = UIColor.red.cgColor
                confirmTextField.layer.addSublayer(bottomBorderCnfrm)

            }
        }
        else
        {
            if passwordTextField.text == confirmTextField.text
            {
                myName = customerNameTextField.text!
                myPassword = passwordTextField.text!
                myUserName = usernameTextField.text!
            let vc = storyboard?.instantiateViewController(withIdentifier: "LoginViewController") as! ViewController
            self.navigationController?.pushViewController(vc, animated: true)
            }
            
            else
            {
                let alertController = UIAlertController(title: "Error", message:
                        "Check Password and Confirm Password!", preferredStyle: .alert)
                    alertController.addAction(UIAlertAction(title: "Dismiss", style: .destructive))

                    self.present(alertController, animated: true, completion: nil)
            }
        }
    }
    
    
    func AddBottomBorders() {
       
       let bottomBorderUsername = CALayer()
        bottomBorderUsername.frame = CGRect(x:0, y: self.usernameTextField.frame.size.height - thickness, width: self.usernameTextField.frame.width, height:thickness)
       bottomBorderUsername.backgroundColor = UIColor.black.cgColor
        
        let bottomBorderPassword = CALayer()
         bottomBorderPassword.frame = CGRect(x:0, y: self.passwordTextField.frame.size.height - thickness, width: self.passwordTextField.frame.width, height:thickness)
        bottomBorderPassword.backgroundColor = UIColor.black.cgColor
        
        let bottomBorderName = CALayer()
         bottomBorderName.frame = CGRect(x:0, y: self.customerNameTextField.frame.size.height - thickness, width: self.customerNameTextField.frame.width, height:thickness)
        bottomBorderName.backgroundColor = UIColor.black.cgColor
        
        let bottomBorderCnfrm = CALayer()
         bottomBorderCnfrm.frame = CGRect(x:0, y: self.customerNameTextField.frame.size.height - thickness, width: self.customerNameTextField.frame.width, height:thickness)
        bottomBorderCnfrm.backgroundColor = UIColor.black.cgColor
        
       usernameTextField.layer.addSublayer(bottomBorderUsername)
        passwordTextField.layer.addSublayer(bottomBorderPassword)
        customerNameTextField.layer.addSublayer(bottomBorderName)
        confirmTextField.layer.addSublayer(bottomBorderCnfrm)
    }

    
    func setGradientBackgroundBack() {
        let colorTop = UIColor(red: 254.0/255.0, green: 208.0/255.0, blue: 79.0/255.0, alpha: 1.0).cgColor
        let colormiddle =  UIColor(red: 255.0/255.0, green: 255.0/255.0, blue: 255.0/255.0, alpha: 1.0).cgColor
        let gradientLayer = CAGradientLayer()
        
        gradientLayer.colors = [colorTop,colormiddle]
        gradientLayer.locations = [0.0, 1.0]
        gradientLayer.frame = self.view.bounds
                
        self.backView.layer.insertSublayer(gradientLayer, at:0)
        
    }
    
    func setGradientBackgroundView() {
        let colorTop = UIColor(red: 254.0/255.0, green: 208.0/255.0, blue: 79.0/255.0, alpha: 1.0).cgColor
        let colormiddle =  UIColor(red: 255.0/255.0, green: 255.0/255.0, blue: 255.0/255.0, alpha: 1.0).cgColor
        let gradientLayer = CAGradientLayer()
        
        gradientLayer.colors = [colorTop,colormiddle]
        gradientLayer.locations = [0.0, 1.0]
        gradientLayer.frame = self.view.bounds
                
        self.view.layer.insertSublayer(gradientLayer, at:0)
        
    }
    
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        if textField == self.customerNameTextField
        {
            let bottomBorderName = CALayer()
             bottomBorderName.frame = CGRect(x:0, y: self.customerNameTextField.frame.size.height - thickness, width: self.customerNameTextField.frame.width, height:thickness)
            bottomBorderName.backgroundColor = UIColor.black.cgColor
            customerNameTextField.layer.addSublayer(bottomBorderName)
            
            self.customerNameTextField.becomeFirstResponder()
        }
        if textField == self.usernameTextField
        {
            let bottomBorderUsername = CALayer()
             bottomBorderUsername.frame = CGRect(x:0, y: self.usernameTextField.frame.size.height - thickness, width: self.usernameTextField.frame.width, height:thickness)
            bottomBorderUsername.backgroundColor = UIColor.black.cgColor
            usernameTextField.layer.addSublayer(bottomBorderUsername)

            self.usernameTextField.becomeFirstResponder()
        }
        
        if textField == self.passwordTextField
        {
            let bottomBorderPassword = CALayer()
            bottomBorderPassword.frame = CGRect(x:0, y: self.passwordTextField.frame.size.height - thickness, width: self.passwordTextField.frame.width, height:thickness)
           bottomBorderPassword.backgroundColor = UIColor.black.cgColor
            passwordTextField.layer.addSublayer(bottomBorderPassword)
            
            self.passwordTextField.becomeFirstResponder()
        }
        if textField == self.confirmTextField
        {
            let bottomBorderCnfrm = CALayer()
             bottomBorderCnfrm.frame = CGRect(x:0, y: self.customerNameTextField.frame.size.height - thickness, width: self.customerNameTextField.frame.width, height:thickness)
            bottomBorderCnfrm.backgroundColor = UIColor.black.cgColor
            confirmTextField.layer.addSublayer(bottomBorderCnfrm)
            
            self.confirmTextField.becomeFirstResponder()
        }
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        if textField == self.customerNameTextField
        {
            if textField.text == ""
            {
                let bottomBorderName = CALayer()
                 bottomBorderName.frame = CGRect(x:0, y: self.customerNameTextField.frame.size.height - thickness, width: self.customerNameTextField.frame.width, height:thickness)
                bottomBorderName.backgroundColor = UIColor.red.cgColor
                customerNameTextField.layer.addSublayer(bottomBorderName)
            }
        }
        
        if textField == self.usernameTextField
        {
            if textField.text == ""
            {
            let bottomBorderUsername = CALayer()
             bottomBorderUsername.frame = CGRect(x:0, y: self.usernameTextField.frame.size.height - thickness, width: self.usernameTextField.frame.width, height:thickness)
            bottomBorderUsername.backgroundColor = UIColor.red.cgColor
            usernameTextField.layer.addSublayer(bottomBorderUsername)
            }
        }
        
        if textField == self.passwordTextField
        {
            if textField.text == ""
            {
            let bottomBorderPassword = CALayer()
            bottomBorderPassword.frame = CGRect(x:0, y: self.passwordTextField.frame.size.height - thickness, width: self.passwordTextField.frame.width, height:thickness)
           bottomBorderPassword.backgroundColor = UIColor.red.cgColor
            passwordTextField.layer.addSublayer(bottomBorderPassword)
            }
        }
        
        if textField == self.confirmTextField
        {
            if textField.text == ""
            {
            let bottomBorderCnfrm = CALayer()
             bottomBorderCnfrm.frame = CGRect(x:0, y: self.customerNameTextField.frame.size.height - thickness, width: self.customerNameTextField.frame.width, height:thickness)
            bottomBorderCnfrm.backgroundColor = UIColor.red.cgColor
            confirmTextField.layer.addSublayer(bottomBorderCnfrm)
            }
        }
        
    }
    
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if textField == self.customerNameTextField
        {
            self.usernameTextField.becomeFirstResponder()
        }
        if textField == self.usernameTextField
        {
            self.passwordTextField.becomeFirstResponder()
        }
        
        if textField == self.passwordTextField
        {
            self.passwordTextField.resignFirstResponder()
        }
        if textField == self.confirmTextField
        {
            self.confirmTextField.resignFirstResponder()
        }
        return true
    }
   

}
