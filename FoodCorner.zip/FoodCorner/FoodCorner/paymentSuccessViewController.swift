//
//  paymentSuccessViewController.swift
//  FoodCorner
//
//  Created by Anilkumar on 07/07/22.
//

import UIKit
import Lottie
import AudioToolbox

class paymentSuccessViewController: UIViewController {

 
    @IBOutlet weak var successView: AnimationView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        successView.contentMode = .scaleAspectFit
          
          // 2. Set animation loop mode
          
        successView.loopMode = .loop
          
          // 3. Adjust animation speed
          
        successView.animationSpeed = 0.5
          
          // 4. Play animation
        successView.play()
        
        successView.topAnchor.constraint(equalTo: view.topAnchor, constant: (UIScreen.main.bounds.height/2)-100).isActive = true
        successView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 0).isActive = true
        successView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: 0).isActive = true
        successView.heightAnchor.constraint(equalToConstant: 200).isActive = true
        successView.translatesAutoresizingMaskIntoConstraints = false
        
        
//        setGradientBackground()
        
        
           myCartName.removeAll()
            MyCartAmt.removeAll()
        myCartAddress.removeAll()
        
       
        Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(dispVC), userInfo: nil, repeats: false)
       Timer.scheduledTimer(timeInterval: 3, target: self, selector: #selector(showVC), userInfo: nil, repeats: false)
        

        // Do any additional setup after loading the view.
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.tabBarController?.tabBar.isHidden = true
        navigationController?.setNavigationBarHidden(true, animated: animated)
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.tabBarController?.tabBar.isHidden = false
        navigationController?.setNavigationBarHidden(false, animated: animated)
    }
    func setGradientBackground() {
        let colorTop = UIColor(red: 254.0/255.0, green: 208.0/255.0, blue: 79.0/255.0, alpha: 1.0).cgColor
        let colormiddle =  UIColor(red: 255.0/255.0, green: 255.0/255.0, blue: 255.0/255.0, alpha: 1.0).cgColor
        
                    
        let gradientLayer = CAGradientLayer()
        gradientLayer.colors = [colorTop,colormiddle]
        gradientLayer.locations = [0.0, 1.0]
        gradientLayer.frame = self.view.bounds
                
        self.view.layer.insertSublayer(gradientLayer, at:0)
    }
    


    @objc func showVC() {
        
        let vc = storyboard?.instantiateViewController(withIdentifier: "HomePageViewController") as! HomePageViewController
        self.navigationController?.pushViewController(vc, animated: true)
        //navigate to your desired VC
    }
    @objc func dispVC() {
        AudioServicesPlaySystemSound(SystemSoundID(1309))
       
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
