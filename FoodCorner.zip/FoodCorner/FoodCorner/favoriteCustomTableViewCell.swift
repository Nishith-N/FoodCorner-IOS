//
//  favoriteCustomTableViewCell.swift
//  FoodCorner
//
//  Created by Anilkumar on 02/07/22.
//

import UIKit

class favoriteCustomTableViewCell: UITableViewCell {
    
    @IBOutlet weak var favAddress: UILabel!
    
    @IBOutlet weak var favItem: UILabel!
    @IBOutlet weak var favImage: UIImageView!
    @IBOutlet weak var button: UIButton!
    
    @IBOutlet weak var favRate: UILabel!
    
    
    let screenSize = UIScreen.main.bounds.size
    
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    

}
