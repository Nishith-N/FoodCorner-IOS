import UIKit

class fastFoodsInfoViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    var selectedProdName = ""
    var fastFoodArr = ["burger","biriyani","fries","burrito","pizza","tuscan chicken pasta"]
    
    var fastFoodRatingArr = ["4.1","5.0","3.5","3.8","4.2","3.5"]
    var fastFoodAddressArr = ["67-71 Dr Krishnasamy Mudaliyar Rd Unit No T17&18, Third Floor, Brookefelds Mall, Sukrawar Pettai, R.S. Puram, Coimbatore, Tamil Nadu 641001","11/5, Avinashi Rd, Peelamedu, Goldwins, Civil Aerodrome Post, Coimbatore, Tamil Nadu 641014","Brookfields Mall, Dr Krishnasamy Mudaliyar Rd, Puthiyavan Nagar, Sukrawar Pettai, R.S. Puram, Coimbatore, Tamil Nadu 641001","Brookfields Mall, Dr Krishnasamy Mudaliyar Rd, Puthiyavan Nagar, Sukrawar Pettai, R.S. Puram, Coimbatore, Tamil Nadu 641001","No. 1391, Avinashi Rd, next to Aryaas Hotel, Peelamedu, Masakalipalayam, Coimbatore, Tamil Nadu 641004","67-71 Dr Krishnasamy Mudaliyar Rd Unit No T17&18, Third Floor, Brookefelds Mall, Sukrawar Pettai, R.S. Puram, Coimbatore, Tamil Nadu 641001"]

 
    @IBOutlet weak var nvHeadView: UIView!
    @IBOutlet var fastFoodInfoTableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        if(UIScreen.main.bounds.height < 600)
        {
            nvHeadView.heightAnchor.constraint(equalToConstant: 120).isActive = true
            nvHeadView.translatesAutoresizingMaskIntoConstraints = false
        }
        fastFoodInfoTableView.delegate = self
        fastFoodInfoTableView.dataSource = self

        
        fastFoodInfoTableView.register(fastFoodInfoTableViewCell.self, forCellReuseIdentifier: "Cell")
        // Do any additional setup after loading the view.
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return fastFoodArr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)as?
                fastFoodInfoTableViewCell else {fatalError("Unable to run")}
        
        
        cell.fastFoodImage.image = UIImage(named: "\(fastFoodArr[indexPath.row])")
        cell.fastFoodName.text = fastFoodArr[indexPath.row].uppercased()
        cell.fastFoodAddress.text = "\(fastFoodAddressArr[indexPath.row])"
        cell.fastFoodRate.text = "\(fastFoodRatingArr[indexPath.row])"
        cell.fastFoodImage.backgroundColor = .gray
          
        
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let vc = storyboard?.instantiateViewController(withIdentifier: "ProductInfoViewController") as! ProductInfoViewController
            self.selectedProdName = "\(nvArr[indexPath.item])"
            vc.productArr = "nvArr"
        
        vc.ProdName = self.selectedProdName
        vc.productAddress = nvAddressArr[indexPath.item]
    
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 120
    }
    


}
