//
//  accountDetailsViewController.swift
//  FoodCorner
//
//  Created by Anilkumar on 05/07/22.
//

import UIKit

class accountDetailsViewController: UIViewController {

    @IBOutlet weak var changePwdBtn: UIButton!
    @IBOutlet weak var accountHeader: UILabel!
    @IBOutlet weak var usernameHead: UILabel!
    @IBOutlet weak var nameHead: UILabel!
    @IBOutlet weak var headerBackView: UIView!
 
    @IBOutlet weak var logoutBackView: UIView!
    @IBOutlet weak var logoutBtn: UIButton!
   
    @IBOutlet weak var usernameLabel: UILabel!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var headerNameLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        logoutBackView.layer.shadowColor = UIColor.lightGray.cgColor
        logoutBackView.layer.shadowOpacity = 10
        logoutBackView.layer.shadowOffset = CGSize.zero
        logoutBackView.layer.shadowRadius = 10
        logoutBackView.layer.cornerRadius = 15.0
        logoutBtn.layer.cornerRadius = 15.0
        
        
        if(UIScreen.main.bounds.height < 600)
        {
        headerBackView.heightAnchor.constraint(equalToConstant: 120).isActive = true
            headerBackView.translatesAutoresizingMaskIntoConstraints = false
            accountHeader.topAnchor.constraint(equalTo: headerNameLabel.bottomAnchor, constant: 5).isActive = true
            accountHeader.heightAnchor.constraint(equalToConstant: 40).isActive = true
            accountHeader.translatesAutoresizingMaskIntoConstraints = false
            changePwdBtn.topAnchor.constraint(equalTo: usernameLabel.bottomAnchor, constant: 3).isActive = true
            changePwdBtn.translatesAutoresizingMaskIntoConstraints = false
            
        }
        nameLabel.text = myName
        usernameLabel.text = myUserName
        headerNameLabel.text = "Hi, " + myName
        

        // Do any additional setup after loading the view.
    }
    
    @IBAction func logoutBtnAction(_ sender: UIButton) {
        
        let alertController = UIAlertController(title: "Log out", message:
                "Are You Sure to Log Out ? ", preferredStyle: .alert)
        
        
        alertController.addAction(UIAlertAction(title: "Confirm", style: .destructive,handler: {(action: UIAlertAction!) in
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "LoginViewController") as! ViewController
            self.navigationController?.pushViewController(vc, animated: true)
            
        }))
        
        alertController.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: { (action: UIAlertAction!) in

            alertController .dismiss(animated: true, completion: nil)


        }))
        

            self.present(alertController, animated: true, completion: nil)
        
        
    }
    


}
