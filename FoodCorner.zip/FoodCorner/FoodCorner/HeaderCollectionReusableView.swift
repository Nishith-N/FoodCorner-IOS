//
//  HeaderCollectionReusableView.swift
//  FoodCorner
//
//  Created by Anilkumar on 02/07/22.
//

import UIKit

class FirstHeaderCollectionReusableView: UICollectionReusableView {
    

    
    lazy var fastFoodlbl: UILabel = {
        let label = UILabel()
        label.frame = CGRect(x: 0, y: 0, width: 150, height: 50)
//        label.translatesAutoresizingMaskIntoConstraints = false
        label.text = "Fast Food"
        label.font = UIFont(name: "Chalkboard SE Bold", size: 25)
//        label.font = UIFont.systemFont(ofSize: 12)
        return label
    }()
    
    
    
    
    let button : UIButton = {
        let button = UIButton()
        button.setTitle("View All", for: .normal)
        button.setTitleColor(UIColor.darkGray, for: .normal)
        button.frame = CGRect(x: uiwidth-100, y: 0, width: 80, height: 50)
        button.backgroundColor = .white
        
//        button.translatesAutoresizingMaskIntoConstraints = false
      
        button.addTarget(self, action: #selector(buttonTapped), for: .touchUpInside)
        return button
    }()
   
    
    
    var delegate : headerDelegate?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        addSubview(fastFoodlbl)
        addSubview(button)
     

        
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    
    
    
}


extension FirstHeaderCollectionReusableView {
    
    @objc
    func buttonTapped() {
        delegate?.didSelect1()
        
        
    }
    
}
protocol headerDelegate {
    func didSelect1()
}

