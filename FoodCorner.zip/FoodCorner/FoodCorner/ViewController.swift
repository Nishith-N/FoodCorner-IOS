//
//  ViewController.swift
//  FoodCorner
//
//  Created by Byot on 22/06/22.
//

import UIKit

class ViewController: UIViewController,UITextFieldDelegate {

    
   
    let thickness: CGFloat = 2.0
    
    @IBAction func registerNavigate(_ sender: UIButton) {
        
        let vc = storyboard?.instantiateViewController(withIdentifier: "RegisterViewController") as! RegisterViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBOutlet var usernameTextField: UITextField!
    @IBOutlet var passwordTextField: UITextField!
    @IBOutlet var loginBtn: UIButton!
    
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        
        
        self.hideKeyboardWhenTappedAround()
        passwordAddTopAndBottomBorders()
        usernameAddTopAndBottomBorders()
       
        
        usernameTextField.delegate = self
        passwordTextField.delegate = self
        
        loginBtn.layer.cornerRadius = 15.0
        navigationController?.navigationBar.isHidden = false
        loginBtn.clipsToBounds = true
        
        usernameTextField.layer.cornerRadius = 5.0
        usernameTextField.clipsToBounds = true

        
        
        
        passwordTextField.layer.cornerRadius = 5.0
        passwordTextField.clipsToBounds = true
        passwordTextField.isSecureTextEntry = true
        passwordTextField.keyboardType = .emailAddress
        usernameTextField.keyboardType = .emailAddress
        
        
        setGradientBackground()
        
        self.loginBtn.addTarget(self, action: #selector(loginAction(sender:)), for: .touchUpInside)
    }
    
    @objc func loginAction(sender: UIButton)
    {
        if (usernameTextField.text != "" && passwordTextField.text != "")
        {
        if (usernameTextField.text == myUserName && passwordTextField.text == myPassword)
        {
//        let vc = storyboard?.instantiateViewController(withIdentifier: "tabBar") as! tabBar
//            vc.selectedViewController = vc.viewControllers?[0]
//        self.navigationController?.pushViewController(vc, animated: true)
            
            let vc = storyboard?.instantiateViewController(withIdentifier: "loadingViewController") as! loadingViewController
            self.navigationController?.pushViewController(vc, animated: true)
        }
        
        else
        {
            let alertController = UIAlertController(title: "Failed", message:
                    "Invalid Credentials", preferredStyle: .alert)
                alertController.addAction(UIAlertAction(title: "Try Again!!", style: .destructive))

                self.present(alertController, animated: true, completion: nil)
        }
        }
        else
        {
            if usernameTextField.text == ""
            {
                let bottomBorderUsername = CALayer()
                 bottomBorderUsername.frame = CGRect(x:0, y: self.usernameTextField.frame.size.height - thickness, width: self.usernameTextField.frame.width, height:thickness)
                bottomBorderUsername.backgroundColor = UIColor.red.cgColor
                usernameTextField.layer.addSublayer(bottomBorderUsername)
            }
            if passwordTextField.text == ""
            {
                let bottomBorderPassword = CALayer()
                bottomBorderPassword.frame = CGRect(x:0, y: self.passwordTextField.frame.size.height - thickness, width: self.usernameTextField.frame.size.width, height:thickness)
               bottomBorderPassword.backgroundColor = UIColor.red.cgColor
                passwordTextField.layer.addSublayer(bottomBorderPassword)
            }
            let alertController = UIAlertController(title: "Failed", message:
                    "One or more fields are Empty!", preferredStyle: .alert)
                alertController.addAction(UIAlertAction(title: "Try Again!!", style: .destructive))

                self.present(alertController, animated: true, completion: nil)
        }
    }
       
    func passwordAddTopAndBottomBorders() {
       let thickness: CGFloat = 2.0
       let bottomBorder = CALayer()
       bottomBorder.frame = CGRect(x:0, y: self.passwordTextField.frame.size.height - thickness, width: self.usernameTextField.frame.size.width, height:thickness)
       bottomBorder.backgroundColor = UIColor.black.cgColor //CGColor(red: 255.0/255.0, green: 52.0/255.0, blue: 36.0/255.0, alpha: 1.0)
       passwordTextField.layer.addSublayer(bottomBorder)
    }
    
    
    func usernameAddTopAndBottomBorders() {
       let thickness: CGFloat = 2.0
       let bottomBorder = CALayer()
       bottomBorder.frame = CGRect(x:0, y: self.usernameTextField.frame.size.height - thickness, width: self.usernameTextField.frame.width, height:thickness)
        bottomBorder.backgroundColor = UIColor.black.cgColor //CGColor(red: 255.0/255.0, green: 52.0/255.0, blue: 36.0/255.0, alpha: 1.0)
       usernameTextField.layer.addSublayer(bottomBorder)
    }
    

    func setGradientBackground() {
        let colorTop = UIColor(red: 254.0/255.0, green: 208.0/255.0, blue: 79.0/255.0, alpha: 1.0).cgColor
        let colormiddle =  UIColor(red: 255.0/255.0, green: 255.0/255.0, blue: 255.0/255.0, alpha: 1.0).cgColor
        
                    
        let gradientLayer = CAGradientLayer()
        gradientLayer.colors = [colorTop,colormiddle]
        gradientLayer.locations = [0.0, 1.0]
        gradientLayer.frame = self.view.bounds
                
        self.view.layer.insertSublayer(gradientLayer, at:0)
    }
    
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        if textField == self.usernameTextField
        {
            let bottomBorderUsername = CALayer()
             bottomBorderUsername.frame = CGRect(x:0, y: self.usernameTextField.frame.size.height - thickness, width: self.usernameTextField.frame.width, height:thickness)
            bottomBorderUsername.backgroundColor = UIColor.black.cgColor
            usernameTextField.layer.addSublayer(bottomBorderUsername)
            self.usernameTextField.becomeFirstResponder()
        }
        
        if textField == self.passwordTextField
        {
            let bottomBorderPassword = CALayer()
            bottomBorderPassword.frame = CGRect(x:0, y: self.passwordTextField.frame.size.height - thickness, width: self.passwordTextField.frame.width, height:thickness)
           bottomBorderPassword.backgroundColor = UIColor.black.cgColor
            passwordTextField.layer.addSublayer(bottomBorderPassword)
            self.passwordTextField.becomeFirstResponder()
        }
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        if textField == self.usernameTextField
        {
            if textField.text == ""
            {
            let bottomBorderUsername = CALayer()
             bottomBorderUsername.frame = CGRect(x:0, y: self.usernameTextField.frame.size.height - thickness, width: self.usernameTextField.frame.width, height:thickness)
            bottomBorderUsername.backgroundColor = UIColor.red.cgColor
            usernameTextField.layer.addSublayer(bottomBorderUsername)
            }
        }
        
        if textField == self.passwordTextField
        {
            if textField.text == ""
            {
            let bottomBorderPassword = CALayer()
            bottomBorderPassword.frame = CGRect(x:0, y: self.passwordTextField.frame.size.height - thickness, width: self.passwordTextField.frame.width, height:thickness)
           bottomBorderPassword.backgroundColor = UIColor.red.cgColor
            passwordTextField.layer.addSublayer(bottomBorderPassword)
            }
        }
    }
    
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if textField == self.usernameTextField
        {
            self.passwordTextField.becomeFirstResponder()
        }
        
        if textField == self.passwordTextField
        {
            self.passwordTextField.resignFirstResponder()
        }
        return true
    }
    
    
}

extension UIViewController {
    func hideKeyboardWhenTappedAround() {
        let tap = UITapGestureRecognizer(target: self, action: #selector(UIViewController.dismissKeyboard))
        tap.cancelsTouchesInView = false
        view.addGestureRecognizer(tap)
    }
    
    @objc func dismissKeyboard() {
        view.endEditing(true)
    }
}

