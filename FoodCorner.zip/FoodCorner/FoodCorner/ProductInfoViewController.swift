//
//  ProductInfoViewController.swift
//  FoodCorner
//
//  Created by Byot on 02/07/22.
//

import UIKit
import AVFoundation
import AudioToolbox


class ProductInfoViewController: UIViewController {

    @IBOutlet weak var favBtn: UIButton!
    @IBOutlet weak var quantityHeader: UILabel!
    @IBOutlet weak var detailsTextView: UITextView!
    @IBOutlet weak var viewCartBackView: UIView!
    @IBOutlet weak var viewCartQuantityLbl: UILabel!
    @IBOutlet weak var addCartBtn: UIButton!
    @IBOutlet weak var placeOrderBtn: UIButton!
    @IBOutlet weak var totalPriceLabel: UILabel!
    @IBOutlet weak var quantityLabel: UILabel!
    @IBOutlet weak var quantityStepper: UIStepper!
    @IBOutlet weak var priceLabel: UILabel!
    @IBOutlet weak var distanceLabel: UILabel!
    @IBOutlet weak var ProductNameLabel: UILabel!
    @IBOutlet var ProductImageView: UIImageView!
    var ProdName = ""
    var prodPrice = 0.0
    var productArr = ""
    var productAddress = ""
    var productFlag = 0
    var favFlag = 0
    var duration = CGFloat.random(in: 1.0 ... 7.5)
    
   
    override func viewDidLoad() {
        super.viewDidLoad()
        favBtn.setTitle("", for: .normal)
        favBtn.setTitle("", for: .selected)
        
       
        
        
        
        
        
        
        if (UIScreen.main.bounds.height < 600)
        {
            ProductImageView.heightAnchor.constraint(equalToConstant: 100).isActive = true
            ProductImageView.translatesAutoresizingMaskIntoConstraints = false
            
            detailsTextView.heightAnchor.constraint(equalToConstant: 35).isActive = true
            detailsTextView.translatesAutoresizingMaskIntoConstraints = false
            
            quantityLabel.heightAnchor.constraint(equalToConstant: 20).isActive = true
            quantityLabel.translatesAutoresizingMaskIntoConstraints = false
            
            quantityStepper.heightAnchor.constraint(equalToConstant: 15).isActive = true
            quantityStepper.translatesAutoresizingMaskIntoConstraints = false
            
            quantityHeader.heightAnchor.constraint(equalToConstant: 20).isActive = true
            quantityHeader.translatesAutoresizingMaskIntoConstraints = false
            addCartBtn.heightAnchor.constraint(equalToConstant: 30).isActive = true
            addCartBtn.translatesAutoresizingMaskIntoConstraints = false
            placeOrderBtn.heightAnchor.constraint(equalToConstant: 30).isActive = true
            placeOrderBtn.translatesAutoresizingMaskIntoConstraints = false
            
        }
        
        
        quantityLabel.text = "1"
        
        ProductImageView.image = UIImage(named: ProdName)
        ProductNameLabel.text = ProdName.capitalized
        ProductNameLabel.adjustsFontSizeToFitWidth = true
        
        distanceLabel.text = String(format: "%.1f", duration) + " km away"
        
        
        if(productArr == "nvArr")
        {
            prodPrice = nvPrice[ProdName.lowercased()]!
            priceLabel.text = "₹ " + "\(prodPrice)"
            totalPriceLabel.text = "\(prodPrice)"
        }
        
        else if(productArr == "vegArr")
        {
            prodPrice = vegPrice[ProdName.lowercased()]!
            priceLabel.text = "₹ " + "\(vegPrice[ProdName.lowercased()]!)"
            totalPriceLabel.text = "\(prodPrice)"
        }
        else if(productArr == "myFavName")
        {
            prodPrice = currentFavPrice
            priceLabel.text = "₹ " + "\(prodPrice)"
            totalPriceLabel.text = "\(prodPrice)"
        }
        
        
        
        quantityStepper.isContinuous = true
        quantityStepper.maximumValue = 20
        quantityStepper.minimumValue = 1
        
        placeOrderBtn.layer.cornerRadius = 15.0
        placeOrderBtn.clipsToBounds = true
        
        addCartBtn.layer.cornerRadius = 15.0
        addCartBtn.clipsToBounds = true
        addCartBtn.layer.borderColor = UIColor.blue.cgColor
        addCartBtn.layer.borderWidth = 0.5
        viewCartQuantityLbl.text = "\(myCartName.count)"
        
        viewCartBackView.layer.shadowColor = UIColor.lightGray.cgColor
        viewCartBackView.layer.shadowOpacity = 10
        viewCartBackView.layer.shadowOffset = CGSize.zero
        viewCartBackView.layer.shadowRadius = 10
        viewCartBackView.layer.cornerRadius = 10.0
//        viewCartBackView.clipsToBounds = true
        
        if (myCartName.count == 0)
        {
            placeOrderBtn.isEnabled = false
            viewCartBackView.isHidden = true
        }
        else
        {
            placeOrderBtn.isEnabled = true
            viewCartBackView.isHidden = false
        }
        
        
        

        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        if let tabItems = tabBarController?.tabBar.items {
            // In this case we want to modify the badge number of the third tab:
            let tabItem = tabItems[1]
            if(myFavName.count != 0)
            {
            tabItem.badgeValue = "\(myFavName.count)"
            }
            else
            {
                tabItem.badgeValue = nil
            }
        }
        if(myFavName.count != 0)
        {
        for val in Range(0...myFavName.count-1)
        {
            if(myFavName[val] == ProdName)
            {
                favBtn.setImage(UIImage(systemName: "heart.fill"), for: .normal)
                return
            }
            else
            {
                favBtn.setImage(UIImage(systemName: "heart"), for: .normal)
            
            }
        }
    }
        else
        {
            favBtn.setImage(UIImage(systemName: "heart"), for: .normal)
        }
        if (myCartName.count == 0)
        {
            placeOrderBtn.isEnabled = false
            viewCartBackView.isHidden = true
        }
        else
        {
            placeOrderBtn.isEnabled = true
            viewCartBackView.isHidden = false
        }
        
    }
    
    
    @IBAction func StepperValueChanged(_ sender: UIStepper) {
        quantityLabel.text = String(Int(sender.value))
        totalPriceLabel.text =  "\(sender.value*prodPrice)"
    
        
        
    }
    
    
    @IBAction func favBtnAction(_ sender: UIButton) {
        
        if(myFavName.count != 0)
        {
        for val in Range(0...myFavName.count-1)
        {
            if(myFavName[val] == ProdName)
            {
                favBtn.setImage(UIImage(systemName: "heart"), for: .normal)
                myFavName.remove(at: val)
                myFavRate.remove(at: val)
                myFavAddress.remove(at: val)
                if let tabItems = tabBarController?.tabBar.items {
                    // In this case we want to modify the badge number of the third tab:
                    let tabItem = tabItems[1]
                    if(myFavName.count != 0)
                    {
                    tabItem.badgeValue = "\(myFavName.count)"
                    }
                    else
                    {
                        tabItem.badgeValue = nil
                    }
                }
                //delete code to be inserted
                
                return
            }
            
            else{
//
                favFlag = 1
            }
        }
        }
        
        else{
            myFavName.append(ProdName)
            myFavAddress.append(productAddress)
            myFavRate.append(prodPrice)
            favBtn.setImage(UIImage(systemName: "heart.fill"), for: .normal)
        }
        if (favFlag == 1)
        {
            myFavName.append(ProdName)
            myFavAddress.append(productAddress)
            myFavRate.append(prodPrice)
                    favBtn.setImage(UIImage(systemName: "heart.fill"), for: .normal)
            favFlag = 0
        }
        if let tabItems = tabBarController?.tabBar.items {
            // In this case we want to modify the badge number of the third tab:
            let tabItem = tabItems[1]
            if(myFavName.count != 0)
            {
            tabItem.badgeValue = "\(myFavName.count)"
            }
            else
            {
                tabItem.badgeValue = nil
            }
        }
        
        
    }

    @IBAction func addCartBtnAction(_ sender: UIButton) {
        
      
        AudioServicesPlaySystemSound(SystemSoundID(1035))
        
        if(myCartName.count != 0)
        {
            placeOrderBtn.isEnabled = true
        for val in Range(0...myCartName.count-1)
        {
            if (myCartName[val] == ProdName)
            {
                let oldprice = MyCartAmt[val]
                let oldQuant = quanti[val]
                MyCartAmt[val] = Double(oldprice + Double(quantityLabel.text!)!*prodPrice)
                quanti[val] = Int(oldQuant + Int(quantityLabel.text!)!)
                productFlag = 0
                return
            }
            else
            {
                productFlag = 1
               
            }
        }
        }
        else
        {
            placeOrderBtn.isEnabled = true
            myCartName.append(ProdName)
            MyCartAmt.append(Double(totalPriceLabel.text!)!)
            myCartAddress.append(productAddress)
            quanti.append(Int(quantityLabel.text!)!)
        }
        
        if(productFlag == 1)
        {
        myCartName.append(ProdName)
        MyCartAmt.append(Double(totalPriceLabel.text!)!)
        myCartAddress.append(productAddress)
            quanti.append(Int(quantityLabel.text!)!)
            productFlag = 0
        }
        if(myCartName.count == 0)
        {
            viewCartBackView.isHidden = true
        }
        else{
            viewCartBackView.isHidden = false
        }
        
        viewCartQuantityLbl.text = "\(myCartName.count)"
        
        
        
        
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
extension UIDevice {
    static func vibrate() {
        AudioServicesPlaySystemSound(kSystemSoundID_Vibrate)
    }
}
